// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode 100 QR codes, ECC M\n", stdout);
  return lionss_run_workload("QrBatch");
}
