// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Hot-spot temperature, IEEE C57.91"); }
int main(){
  announce();
  return lionss_run_workload("XfmrLoading");
}
