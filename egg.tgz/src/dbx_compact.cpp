// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compact SSTables, level 2\n", stdout);
  return lionss_run_workload("dbx_compact");
}
