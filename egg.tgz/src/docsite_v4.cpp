// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Link-check generated site"); }
int main(){
  announce();
  return lionss_run_workload("docsite_v4");
}
