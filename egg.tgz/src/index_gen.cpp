// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Back-of-book index with page refs"); }
int main(){
  announce();
  return lionss_run_workload("index_gen");
}
