// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rehearse rolling drain"); }
int main(){
  announce();
  return lionss_run_workload("k8sDrainRehearsal");
}
