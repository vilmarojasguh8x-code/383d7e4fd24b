// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Lighthouse PWA audit"); }
int main(){
  announce();
  return lionss_run_workload("pwa-shell");
}
