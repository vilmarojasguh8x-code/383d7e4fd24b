// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Demosaic, WB 5200K, export\n", stdout);
  return lionss_run_workload("raw-develop");
}
