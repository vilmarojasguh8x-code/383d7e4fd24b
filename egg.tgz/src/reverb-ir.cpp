// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Convolve dry stem"); }
int main(){
  announce();
  return lionss_run_workload("reverb-ir");
}
