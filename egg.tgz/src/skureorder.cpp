// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compute reorder points\n", stdout);
  return lionss_run_workload("skureorder");
}
