// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Rebalance tenants across 8 shards\n", stdout);
  return lionss_run_workload("tenancyShard");
}
