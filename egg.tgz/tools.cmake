# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(hoa-budget src/hoa-budget.cpp)
set_property(TARGET hoa-budget PROPERTY CXX_STANDARD 11)
target_link_libraries(hoa-budget lionss pthread)

add_executable(covMerge src/covMerge.cpp)
set_property(TARGET covMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(covMerge lionss pthread)

add_executable(reverb-ir src/reverb-ir.cpp)
set_property(TARGET reverb-ir PROPERTY CXX_STANDARD 11)
target_link_libraries(reverb-ir lionss pthread)

add_executable(promolift src/promolift.cpp)
set_property(TARGET promolift PROPERTY CXX_STANDARD 11)
target_link_libraries(promolift lionss pthread)

add_executable(AisDecode src/AisDecode.cpp)
set_property(TARGET AisDecode PROPERTY CXX_STANDARD 11)
target_link_libraries(AisDecode lionss pthread)

add_executable(XfmrLoading src/XfmrLoading.cpp)
set_property(TARGET XfmrLoading PROPERTY CXX_STANDARD 11)
target_link_libraries(XfmrLoading lionss pthread)

add_executable(dbx_compact src/dbx_compact.cpp)
set_property(TARGET dbx_compact PROPERTY CXX_STANDARD 11)
target_link_libraries(dbx_compact lionss pthread)

add_executable(ProtoGenAll src/ProtoGenAll.cpp)
set_property(TARGET ProtoGenAll PROPERTY CXX_STANDARD 11)
target_link_libraries(ProtoGenAll lionss pthread)

add_executable(pumice src/pumice.cpp)
set_property(TARGET pumice PROPERTY CXX_STANDARD 11)
target_link_libraries(pumice lionss pthread)

add_executable(raw-develop src/raw-develop.cpp)
set_property(TARGET raw-develop PROPERTY CXX_STANDARD 11)
target_link_libraries(raw-develop lionss pthread)

add_executable(sdrfmdemod src/sdrfmdemod.cpp)
set_property(TARGET sdrfmdemod PROPERTY CXX_STANDARD 11)
target_link_libraries(sdrfmdemod lionss pthread)

add_executable(ballast-calc src/ballast-calc.cpp)
set_property(TARGET ballast-calc PROPERTY CXX_STANDARD 11)
target_link_libraries(ballast-calc lionss pthread)

add_executable(bc7_batch src/bc7_batch.cpp)
set_property(TARGET bc7_batch PROPERTY CXX_STANDARD 11)
target_link_libraries(bc7_batch lionss pthread)

add_executable(seocrawl src/seocrawl.cpp)
set_property(TARGET seocrawl PROPERTY CXX_STANDARD 11)
target_link_libraries(seocrawl lionss pthread)

add_executable(index_gen src/index_gen.cpp)
set_property(TARGET index_gen PROPERTY CXX_STANDARD 11)
target_link_libraries(index_gen lionss pthread)

add_executable(scte35-insert src/scte35-insert.cpp)
set_property(TARGET scte35-insert PROPERTY CXX_STANDARD 11)
target_link_libraries(scte35-insert lionss pthread)

add_executable(yew src/yew.cpp)
set_property(TARGET yew PROPERTY CXX_STANDARD 11)
target_link_libraries(yew lionss pthread)

add_executable(k8sDrainRehearsal src/k8sDrainRehearsal.cpp)
set_property(TARGET k8sDrainRehearsal PROPERTY CXX_STANDARD 11)
target_link_libraries(k8sDrainRehearsal lionss pthread)

add_executable(skureorder src/skureorder.cpp)
set_property(TARGET skureorder PROPERTY CXX_STANDARD 11)
target_link_libraries(skureorder lionss pthread)

add_executable(hiveMonitor src/hiveMonitor.cpp)
set_property(TARGET hiveMonitor PROPERTY CXX_STANDARD 11)
target_link_libraries(hiveMonitor lionss pthread)

add_executable(docsite_v4 src/docsite_v4.cpp)
set_property(TARGET docsite_v4 PROPERTY CXX_STANDARD 11)
target_link_libraries(docsite_v4 lionss pthread)

add_executable(QrBatch src/QrBatch.cpp)
set_property(TARGET QrBatch PROPERTY CXX_STANDARD 11)
target_link_libraries(QrBatch lionss pthread)

add_executable(mantis src/mantis.cpp)
set_property(TARGET mantis PROPERTY CXX_STANDARD 11)
target_link_libraries(mantis lionss pthread)

add_executable(pwa-shell src/pwa-shell.cpp)
set_property(TARGET pwa-shell PROPERTY CXX_STANDARD 11)
target_link_libraries(pwa-shell lionss pthread)

add_executable(tenancyShard src/tenancyShard.cpp)
set_property(TARGET tenancyShard PROPERTY CXX_STANDARD 11)
target_link_libraries(tenancyShard lionss pthread)

add_executable(shortlink src/shortlink.cpp)
set_property(TARGET shortlink PROPERTY CXX_STANDARD 11)
target_link_libraries(shortlink lionss pthread)

add_executable(aquaponics_ctl src/aquaponics_ctl.cpp)
set_property(TARGET aquaponics_ctl PROPERTY CXX_STANDARD 11)
target_link_libraries(aquaponics_ctl lionss pthread)

add_executable(hdl-sim-uart src/hdl-sim-uart.cpp)
set_property(TARGET hdl-sim-uart PROPERTY CXX_STANDARD 11)
target_link_libraries(hdl-sim-uart lionss pthread)

add_executable(fjord src/fjord.cpp)
set_property(TARGET fjord PROPERTY CXX_STANDARD 11)
target_link_libraries(fjord lionss pthread)

add_executable(paginateBook src/paginateBook.cpp)
set_property(TARGET paginateBook PROPERTY CXX_STANDARD 11)
target_link_libraries(paginateBook lionss pthread)

